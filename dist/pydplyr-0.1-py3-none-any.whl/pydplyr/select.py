def select():
    """
    A simple select function that prints a message when called.
    """
    return "This is a select function"


if __name__ == "__main__":
    select()
